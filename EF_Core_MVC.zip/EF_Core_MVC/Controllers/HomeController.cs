﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EF_Core_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace EF_Core_MVC.Controllers
{
    public class HomeController : Controller
    {
        private DBCtx Context { get; }
        public HomeController(DBCtx _context)
        {
            this.Context = _context;
        }

        public IActionResult Index()
        {
            List<Customer> customers = (from customer in this.Context.Customers.Take(10)
                                        select customer).ToList();
            return View(customers);
        }
    }
}