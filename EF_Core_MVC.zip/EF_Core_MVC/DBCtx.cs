﻿using EF_Core_MVC.Models;
using Microsoft.EntityFrameworkCore;
namespace EF_Core_MVC
{
    public class DBCtx : DbContext
    {
        public DBCtx(DbContextOptions<DBCtx> options) : base(options)
        {
        }

        public DbSet<Customer> Customers { get; set; }
    }
}